import React from 'react'
import useDocumentTitle from './useDocumentTitle'
export default function Contact() {
   useDocumentTitle("Contact")
  

  return (
    <div>
        <h1>Contact</h1>
        <b>This is contact page</b>
    </div>
  )
}
