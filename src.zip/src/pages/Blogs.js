import React from 'react'
import useDocumentTitle from './useDocumentTitle'
export default function Blogs() {
   
    useDocumentTitle("Blogs")
  

  return (
    <div>
        <h1>Blogs</h1>
        <b>This is blog page</b>
    </div>
  )
}
